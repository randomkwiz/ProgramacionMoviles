/** Automatically generated file. DO NOT MODIFY */
package es.iesnervion.android.rad;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}